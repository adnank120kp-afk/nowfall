import React from 'react';
import { soundSynth } from '../audio';
import { WeatherMode } from '../types';

interface HeaderHUDProps {
  weather: WeatherMode;
  onCycleWeather: () => void;
  wallet: number;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenDistrictModal: () => void;
  onToggleVehicle: () => void;
  inVehicle: boolean;
}

const WEATHER_LABELS: Record<WeatherMode, { label: string; icon: string }> = {
  monsoon: { label: 'കേരള മൺസൂൺ (Monsoon Active)', icon: '🌧️' },
  morning: { label: 'മൂടൽമഞ്ഞുള്ള പ്രഭാതം (Misty Sunrise)', icon: '🌫️' },
  evening: { label: 'സന്ധ്യാ സൂര്യൻ (Golden Evening)', icon: '🌅' },
};

export function HeaderHUD({
  weather,
  onCycleWeather,
  wallet,
  isMuted,
  onToggleMute,
  onOpenDistrictModal,
  onToggleVehicle,
  inVehicle,
}: HeaderHUDProps) {
  const currentWeatherData = WEATHER_LABELS[weather];

  return (
    <header className="relative z-50 flex items-center justify-between px-4 sm:px-6 py-2.5 border-b border-emerald-800/40 bg-[#06140ee8] backdrop-blur-xl shadow-xl select-none">
      {/* Game Logo & Kerala Authentic Tagline */}
      <div className="flex items-center gap-3 sm:gap-4">
        <div
          className="relative flex items-center justify-center w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 via-emerald-500 to-[#a83822] p-[1px] shadow-lg shadow-emerald-950/80 cursor-pointer transition-transform hover:scale-105"
          onClick={onOpenDistrictModal}
          title="Change Kerala District"
        >
          <div className="w-full h-full bg-[#081711] rounded-[11px] flex items-center justify-center text-xl">
            🌴
          </div>
          <span className="absolute -bottom-1 -right-1 flex h-4 px-1 items-center justify-center rounded-full bg-amber-400 text-[8px] font-mono font-black text-black border border-[#081711] tracking-wider">
            KERALA
          </span>
        </div>

        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-heading text-base sm:text-lg font-extrabold tracking-wider text-white uppercase flex items-center gap-2">
              NAATTILE SCENE
              <span className="text-[11px] sm:text-xs px-2 py-0.5 rounded font-malayalam font-black bg-[#0f5132] text-emerald-300 border border-emerald-400/40 tracking-normal">
                ഇത് കേരളമാണ്!
              </span>
              <span className="hidden sm:inline-block text-[10px] font-mono text-emerald-300/80">
                (Kizhakkumpuram Open World)
              </span>
            </h1>
            <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-900/60 border border-emerald-400/50">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_#34d399]"></span>
              <span className="text-[10px] font-mono font-extrabold text-emerald-200">2K QHD • 120 FPS</span>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs text-emerald-300/85 font-medium mt-0.5">
            <span className="font-malayalam text-amber-300 flex items-center gap-1.5 font-semibold text-[11px] sm:text-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
              <span>കിഴക്കുംപുറം വില്ലേജ് (Kizhakkumpuram Junction)</span>
            </span>
            <span className="w-1 h-1 rounded-full bg-emerald-500 hidden sm:inline-block"></span>
            <span className="font-mono text-[11px] text-zinc-300 hidden sm:inline-block">SH-17 Highway • കോഴിക്കോട് 24 KM</span>
          </div>
        </div>
      </div>

      {/* Center: Live Weather Status with Kerala Monsoon Active */}
      <div className="hidden lg:flex items-center gap-3.5 hud-panel px-4 py-1.5 rounded-full border border-emerald-500/30">
        <div className="flex items-center gap-2 border-r border-emerald-800/60 pr-3.5">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
          <div className="flex items-center gap-1.5 text-xs font-mono">
            <span className="text-zinc-300">Weather:</span>
            <span className="text-cyan-300 font-extrabold font-malayalam">
              {currentWeatherData.icon} {currentWeatherData.label}
            </span>
          </div>
        </div>
        <button
          className="px-2.5 py-0.5 rounded-md bg-[#0f5132] hover:bg-emerald-700 text-[11px] text-emerald-200 transition-all border border-emerald-400/40 shadow-sm flex items-center gap-1 font-mono font-bold active:scale-95 cursor-pointer"
          onClick={onCycleWeather}
        >
          <span>Toggle Sky</span> 🌦️
        </button>
      </div>

      {/* Right: Dynamic Audio Action Buttons & Audio Toggle */}
      <div className="flex items-center gap-2 sm:gap-2.5">
        {/* Quick Audio Horn Buttons */}
        <div className="hidden sm:flex items-center gap-1.5 bg-black/50 p-1 rounded-xl border border-emerald-900/60">
          <button
            className="px-2.5 py-1 rounded-lg bg-emerald-950/80 hover:bg-[#0f5132] text-amber-300 border border-amber-400/30 text-xs font-mono font-bold transition-transform active:scale-95 flex items-center gap-1 cursor-pointer"
            onClick={() => soundSynth.playSound('airhorn')}
            title="Kerala Bus Musical Air Horn [H]"
          >
            <span>🎺 Air Horn</span>
            <span className="text-[9px] px-1 rounded bg-black/40 text-zinc-300">[H]</span>
          </button>
          <button
            className="px-2.5 py-1 rounded-lg bg-emerald-950/80 hover:bg-[#0f5132] text-emerald-200 border border-emerald-500/30 text-xs font-mono font-bold transition-transform active:scale-95 flex items-center gap-1 cursor-pointer"
            onClick={() => soundSynth.playSound('teaglass')}
            title="Chaya Kada Glass Clink [T]"
          >
            <span>☕ Tea Clink</span>
            <span className="text-[9px] px-1 rounded bg-black/40 text-zinc-300">[T]</span>
          </button>
          <button
            className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-transform active:scale-95 flex items-center gap-1 cursor-pointer ${
              inVehicle
                ? 'bg-amber-500 text-black border border-amber-300 animate-pulse'
                : 'bg-emerald-950/80 hover:bg-[#0f5132] text-yellow-300 border border-yellow-500/30'
            }`}
            onClick={onToggleVehicle}
            title="Babu Auto Horn / Ride [F]"
          >
            <span>🛺 {inVehicle ? 'Exit Auto' : 'Babu Auto'}</span>
            <span className="text-[9px] px-1 rounded bg-black/40 text-zinc-200">[F]</span>
          </button>
        </div>

        {/* Mobile quick toggle sky */}
        <button
          className="lg:hidden px-2 py-1 rounded-lg bg-[#0f5132] text-emerald-200 text-xs font-mono font-bold border border-emerald-400/40"
          onClick={onCycleWeather}
        >
          {currentWeatherData.icon}
        </button>

        {/* Wallet Indicator */}
        <div className="flex items-center gap-2 hud-panel px-3 py-1.5 rounded-xl border border-emerald-700/30">
          <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-bold text-xs border border-emerald-500/30">
            ₹
          </div>
          <div>
            <div className="text-[9px] uppercase text-zinc-400 font-mono leading-none">Wallet</div>
            <div className="text-xs font-bold text-emerald-300 font-mono">₹ {wallet}</div>
          </div>
        </div>

        {/* Download Project ZIP Button */}
        <a
          href="/naattile-scene-kerala.zip"
          download="naattile-scene-kerala-3d.zip"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black text-xs font-mono font-extrabold shadow-md border border-amber-300/60 active:scale-95 transition-transform cursor-pointer"
          title="Download complete project ZIP file"
        >
          <span>📦</span>
          <span className="hidden sm:inline">ZIP File</span>
        </a>

        {/* Mute/Sound Button */}
        <button
          className="w-8 h-8 rounded-xl bg-black/40 border border-emerald-900/60 flex items-center justify-center text-emerald-300 hover:bg-emerald-800/40 text-sm shadow-md cursor-pointer transition-colors"
          onClick={onToggleMute}
          title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
        >
          {isMuted ? '🔇' : '🔊'}
        </button>
      </div>
    </header>
  );
}
