import { useState, useCallback } from 'react';
import { HeaderHUD } from './components/HeaderHUD';
import { RadarHUD } from './components/RadarHUD';
import { RightSidebarHUD } from './components/RightSidebarHUD';
import { DialogueHUD } from './components/DialogueHUD';
import { ControlsHUD } from './components/ControlsHUD';
import { DistrictModal } from './components/DistrictModal';
import { ThreeKeralaWorld } from './components/ThreeKeralaWorld';
import { soundSynth } from './audio';
import { WeatherMode, NPCEntity } from './types';

const DIALOGUE_SEQUENCE: NPCEntity[] = [
  {
    id: 'babu',
    avatar: '🛺',
    tag: 'AUTO',
    name: 'Babu Chettan (ഓട്ടോ ബാബു)',
    malayalamName: 'ഓട്ടോ ബാബു',
    role: 'Auto Union Secretary',
    dialogue: '“ഇത് കേരളമാണ് ഉണ്ണീ! ആ അനന്തപുരി ബസ്സിന്റെ മുന്നിൽ ഓട്ടോ കൊണ്ട് കേറ്റിയാൽ ഡ്രൈവർ എയർ ഹോൺ അടിച്ച് പറപ്പിക്കും! വേണമെങ്കിൽ എന്റെ ഓട്ടോയിൽ കേറിക്കോ!”',
  },
  {
    id: 'mohnan',
    avatar: '☕',
    tag: 'CHAYA',
    name: 'Mohanan Nair (നായർ ചേട്ടൻ)',
    malayalamName: 'നായർ ചേട്ടൻ',
    role: 'Tea Master',
    dialogue: '“മഴ കനക്കുകയാണ്! കടത്തിണ്ണയിൽ ഇരുന്ന് മനോരമ പത്രം വായിക്കൂ, ചൂട് പരിപ്പുവടയും പഴംപൊരിയും റെഡിയാണ്!”',
  },
  {
    id: 'aboobacker',
    avatar: '🕌',
    tag: 'ELDER',
    name: 'Aboobacker Kaka (അബൂബക്കർ കാക്ക)',
    malayalamName: 'അബൂബക്കർ കാക്ക',
    role: 'Community Elder',
    dialogue: '“അസ്സലാമു അലൈക്കും ഉണ്ണീ! പള്ളി റോഡിലൂടെ പതുക്കെ നടന്നോളൂ. മഴയത്ത് ഇവിടെ വരാന്തയിൽ വിശ്രമിക്കാം.”',
  },
  {
    id: 'goat',
    avatar: '🐐',
    tag: 'GOAT',
    name: 'Aadu Thoma (ആട് തോമ 🐐)',
    malayalamName: 'ആട് തോമ',
    role: 'Village Notorious Goat',
    dialogue: '“മേഹ്ഹ്ഹ്ഹ്! (നിങ്ങൾ ഏത് ജില്ലക്കാരനായാലും എന്റെ വഴിയേ വരരുത്!)”',
  },
];

const WEATHER_MODES: WeatherMode[] = ['monsoon', 'morning', 'evening'];

export default function App() {
  const [wallet, setWallet] = useState<number>(420);
  const [weather, setWeather] = useState<WeatherMode>('monsoon');
  const [inVehicle, setInVehicle] = useState<boolean>(false);
  const [activeDialogue, setActiveDialogue] = useState<NPCEntity | null>(null);
  const [dialogueIndex, setDialogueIndex] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [districtModalOpen, setDistrictModalOpen] = useState<boolean>(false);
  const [activeDistrict, setActiveDistrict] = useState<string>('Kozhikode');
  const [focusTarget, setFocusTarget] = useState<'auto' | 'bus' | 'chaya' | 'mosque' | null>(null);
  const [newspaperStory, setNewspaperStory] = useState<string>(
    '“ഇന്ന് ഇടവപ്പാതി കനക്കും! അനന്തപുരി സൂപ്പർ ഫാസ്റ്റ് ബസ്സിന്റെ പുതിയ എയർ ഹോൺ നാട്ടിൽ ചർച്ചയായി!”'
  );

  const cycleWeather = useCallback(() => {
    setWeather((prev) => {
      const idx = WEATHER_MODES.indexOf(prev);
      const nextMode = WEATHER_MODES[(idx + 1) % WEATHER_MODES.length];
      if (nextMode === 'monsoon') {
        soundSynth.playSound('teaglass');
      }
      return nextMode;
    });
  }, []);

  const handleOrder = useCallback(
    (item: string, price: number) => {
      if (wallet >= price) {
        setWallet((w) => w - price);
        soundSynth.playSound('coin');
        soundSynth.playSound('teaglass');
        setActiveDialogue({
          id: 'order',
          avatar: '☕',
          tag: 'CHAYA',
          name: 'Mohanan Nair (നായർ ചേട്ടൻ)',
          malayalamName: 'നായർ ചേട്ടൻ',
          role: 'Tea Master',
          dialogue: `“ഇതാ നല്ല ചൂട് ${item}! കഴിക്ക് ഉണ്ണീ, കൂടെ ഒരു ചൂട് ചായയും ഒഴിച്ചു തരാം!”`,
        });
      } else {
        soundSynth.playSound('autohorn');
        setActiveDialogue({
          id: 'no-money',
          avatar: '☕',
          tag: 'CHAYA',
          name: 'Mohanan Nair (നായർ ചേട്ടൻ)',
          malayalamName: 'നായർ ചേട്ടൻ',
          role: 'Tea Master',
          dialogue: '“കാശു തികയില്ലല്ലോ ഉണ്ണീ! അടുത്ത തവണ വരുമ്പോൾ തന്നാൽ മതി!”',
        });
      }
    },
    [wallet]
  );

  const handleToggleMute = useCallback(() => {
    setIsMuted((prev) => {
      const next = !prev;
      soundSynth.setMuted(next);
      return next;
    });
  }, []);

  const handleFocusPOI = useCallback((poi: 'auto' | 'bus' | 'chaya' | 'mosque') => {
    setFocusTarget(poi);
    if (poi === 'chaya') {
      soundSynth.playSound('teaglass');
      setActiveDialogue({
        id: 'chaya',
        avatar: '☕',
        tag: 'CHAYA',
        name: 'Mohanan Nair (നായർ ചേട്ടൻ)',
        malayalamName: 'നായർ ചേട്ടൻ',
        role: 'Tea Master',
        dialogue: '“നായർസ് ചായക്കടയിലേക്ക് സ്വാഗതം! ചൂടുള്ള സുലൈമാനിയും പഴംപൊരിയും കഴിക്കാം!”',
      });
    } else if (poi === 'mosque') {
      soundSynth.playSound('teaglass');
      setActiveDialogue({
        id: 'mosque',
        avatar: '🕌',
        tag: 'MOSQUE',
        name: 'Aboobacker Kaka (അബൂബക്കർ കാക്ക)',
        malayalamName: 'അബൂബക്കർ കാക്ക',
        role: 'Community Elder',
        dialogue: '“കിഴക്കുംപുറം ജുമാ മസ്ജിദ് ശാന്തമായ അന്തരീക്ഷം പ്രദാനം ചെയ്യുന്നു. മഴയത്ത് ഇവിടെ വിശ്രമിക്കാം.”',
      });
    } else if (poi === 'auto') {
      soundSynth.playSound('autohorn');
      setActiveDialogue({
        id: 'babu',
        avatar: '🛺',
        tag: 'AUTO',
        name: 'Babu Chettan (ഓട്ടോ ബാബു)',
        malayalamName: 'ഓട്ടോ ബാബു',
        role: 'Auto Union Secretary',
        dialogue: '“എങ്ങോട്ടാ പോവേണ്ടത്? [F] അമർത്തിയാൽ എന്റെ ഓട്ടോ ഓടിക്കാം!”',
      });
    } else if (poi === 'bus') {
      soundSynth.playSound('airhorn');
      setActiveDialogue({
        id: 'ksrtc',
        avatar: '🚌',
        tag: 'KSRTC',
        name: 'KSRTC കൺട്രോളർ',
        malayalamName: 'KSRTC കൺട്രോളർ',
        role: 'Station Master',
        dialogue: '“ആനവണ്ടി സ്റ്റാൻഡിലേക്ക് വരികയാണ്! വേഗത്തിൽ റോഡിൽ നിന്ന് മാറുക!”',
      });
    }
  }, []);

  const handleNextDialogue = useCallback(() => {
    const nextIdx = (dialogueIndex + 1) % DIALOGUE_SEQUENCE.length;
    setDialogueIndex(nextIdx);
    setActiveDialogue(DIALOGUE_SEQUENCE[nextIdx]);
    soundSynth.playSound('teaglass');
  }, [dialogueIndex]);

  const handleDriveAuto = useCallback(() => {
    // Trigger [F] event
    const event = new KeyboardEvent('keydown', { key: 'f' });
    window.dispatchEvent(event);
  }, []);

  const handleHonk = useCallback(() => {
    soundSynth.playSound('airhorn');
  }, []);

  const handleSelectDistrict = useCallback((district: string) => {
    setActiveDistrict(district);
    soundSynth.playSound('teaglass');
    setNewspaperStory(
      `“${district} ജില്ലയിലെ കിഴക്കുംപുറം ഗ്രാമത്തിൽ കനത്ത മഴ! നാട്ടുകാർ ചായക്കടയിൽ സജീവ ചർച്ചയിൽ!”`
    );
  }, []);

  return (
    <div className="h-screen w-screen flex flex-col bg-[#050c09] relative overflow-hidden font-body select-none">
      {/* Scanlines & Ambient Vignette */}
      <div className="scanlines-2k absolute inset-0 z-40 pointer-events-none opacity-30"></div>
      <div className="absolute inset-0 pointer-events-none z-30 bg-[radial-gradient(circle_at_50%_45%,transparent_38%,rgba(4,11,8,0.85)_100%)]"></div>

      {/* 3D EMBEDDED THREE.JS VIEWPORT */}
      <ThreeKeralaWorld
        weather={weather}
        inVehicle={inVehicle}
        onVehicleToggle={setInVehicle}
        onInteractNPC={(npc) => setActiveDialogue(npc)}
        focusTarget={focusTarget}
        onClearFocus={() => setFocusTarget(null)}
      />

      {/* TOP HUD: KERALA OPEN WORLD STATUS & AUDIO CONSOLE */}
      <HeaderHUD
        weather={weather}
        onCycleWeather={cycleWeather}
        wallet={wallet}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenDistrictModal={() => setDistrictModalOpen(true)}
        onToggleVehicle={handleDriveAuto}
        inVehicle={inVehicle}
      />

      {/* MAIN GAME UI OVERLAY WRAPPER */}
      <main className="relative flex-1 w-full h-full overflow-hidden pointer-events-none">
        {/* LEFT HUD: CIRCULAR GPS RADAR & ROADSIDE MILESTONE */}
        <div className="absolute left-4 sm:left-6 top-4 sm:top-5 z-30">
          <RadarHUD onFocusPOI={handleFocusPOI} />
        </div>

        {/* RIGHT HUD: CHAYA KADA CULTURE CARD & SERENE MOSQUE CARD */}
        <div className="absolute right-4 sm:right-6 top-4 sm:top-5 bottom-16 sm:bottom-20 z-30 flex justify-end">
          <RightSidebarHUD
            onOrder={handleOrder}
            onFocusMosque={() => handleFocusPOI('mosque')}
            newspaperStory={newspaperStory}
          />
        </div>

        {/* BOTTOM DIALOGUE BAR */}
        <DialogueHUD
          dialogue={activeDialogue}
          onNext={handleNextDialogue}
          onDriveAuto={handleDriveAuto}
          onDismiss={() => setActiveDialogue(null)}
        />

        {/* BOTTOM CONTROLS BAR */}
        <ControlsHUD
          onHonk={handleHonk}
          onAutoToggle={handleDriveAuto}
          onInteract={() => handleFocusPOI('chaya')}
          inVehicle={inVehicle}
        />
      </main>

      {/* MODAL: KERALA DISTRICT SELECTION */}
      <DistrictModal
        isOpen={districtModalOpen}
        onClose={() => setDistrictModalOpen(false)}
        currentDistrict={activeDistrict}
        onSelectDistrict={handleSelectDistrict}
      />
    </div>
  );
}
